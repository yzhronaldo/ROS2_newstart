#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"

class TurtleBotController : public rclcpp::Node {
public:
  TurtleBotController() : Node("turtle_bot_controller") {
    velocity_publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("turtle1/cmd_vel", 10);
    // 设置圆的半径
    circle_radius_ = 1.0;
    // 假设小海龟的最大速度为1.0 m/s，计算角速度
    angular_velocity_ = 1.0 / circle_radius_;
  }

  // 持续发布速度命令
  void publish_commands() {
    rclcpp::WallRate loop_rate(10);
    while (rclcpp::ok()) {
      // 创建并发布一个Twist消息
      geometry_msgs::msg::Twist velocity_msg;
      velocity_msg.linear.x = 1.0;  // 线速度
      velocity_msg.angular.z = angular_velocity_;  // 角速度
      velocity_publisher_->publish(velocity_msg);
      loop_rate.sleep();
    }
  }

private:
  // 发布者
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr velocity_publisher_;
  // 圆的半径
  double circle_radius_;
  // 角速度
  double angular_velocity_;
};

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  auto controller = std::make_shared<TurtleBotController>();
  // 启动一个线程来发布命令
  std::thread command_thread([controller]() {
    controller->publish_commands();
  });
  rclcpp::spin(controller);
  // 等待命令发布线程结束
  command_thread.join();
  rclcpp::shutdown();
  return 0;
}