#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/twist.hpp" 
#include <chrono>
#include <memory>
#include <random>

class Chaser {
public:
  Chaser() {
    node_ = rclcpp::Node::make_shared("chaser_node");
    subscriber_ = node_->create_subscription<geometry_msgs::msg::PoseStamped>(
      "turtle_pose", 10, std::bind(&Chaser::pose_callback, this, std::placeholders::_1));
    publisher_ = node_->create_publisher<geometry_msgs::msg::PoseStamped>("turtle_a_pose", 10);
    cmd_vel_publisher_ = node_->create_publisher<geometry_msgs::msg::Twist>("turtle1/cmd_vel", 10);

    // 初始化随机数生成器
    random_gen_ = std::mt19937(std::random_device{}());
    boundary_ = 5.0; // 边界设置为5

    pose_a_.pose.position.x = 0.0;
    pose_a_.pose.position.y = 0.0;
    pose_a_.header.frame_id = "world";
  }

  void pose_callback(const geometry_msgs::msg::PoseStamped::SharedPtr msg) {
  // 假设msg是B乌龟的位置
  pose_b_ = *msg;
  geometry_msgs::msg::Twist twist;
  calculate_chase_velocity(twist);
  cmd_vel_publisher_->publish(twist);
//   if (distance < 1.0) {
//     // A乌龟接近B乌龟，隐藏B乌龟的轨迹并随机更新位置
//     pose_b_.pose.position.x = -9999; // 使用一个不可能的位置来模拟隐藏
//     pose_b_.pose.position.y = -9999;
//     publisher_->publish(pose_b_); // 发布隐藏B乌龟的消息
//     // 随机更新B乌龟的位置
//     std::uniform_real_distribution<> dist(-boundary_, boundary_);
//     pose_b_.pose.position.x = dist(random_gen_);
//     pose_b_.pose.position.y = dist(random_gen_);
//     // 检查并规避边界
//     if (check_boundary(pose_b_.pose.position)) {
//       change_direction(pose_b_);
//     }
//     // 发布B乌龟的新位置
//     pose_b_.header.stamp = node_->now();
//     publisher_->publish(pose_b_);
//   } else {
//     // A乌龟未接近B乌龟，实现追逐逻辑
//     // 计算目标方向
//     double dx = pose_b_.pose.position.x - pose_a_.pose.position.x;
//     double dy = pose_b_.pose.position.y - pose_a_.pose.position.y;
//     double magnitude = std::sqrt(dx * dx + dy * dy);
//     // 避免除以零
//     if (magnitude > 0) {
//       dx /= magnitude;
//       dy /= magnitude;
//     }

//     // 向B乌龟移动一步
//     pose_a_.pose.position.x += dx * 0.1; // 移动速度可以根据需要调整
//     pose_a_.pose.position.y += dy * 0.1;

//     // 检查并规避边界
//     if (check_boundary(pose_a_.pose.position)) {
//       change_direction(pose_a_);
//     }

//     // 发布A乌龟的新位置
//     pose_a_.header.stamp = node_->now();
//     publisher_->publish(pose_a_);
//   }
}

void calculate_chase_velocity(geometry_msgs::msg::Twist& twist) {
    double dx = pose_b_.pose.position.x - pose_a_.pose.position.x;
    double dy = pose_b_.pose.position.y - pose_a_.pose.position.y;
    double distance = std::hypot(dx, dy);  // 

    if (distance < 1.0) {
      // A乌龟接近B乌龟，可以在这里实现隐藏逻辑
      pose_b_.pose.position.x = -9999; // 使用一个不可能的位置来模拟隐藏
    pose_b_.pose.position.y = -9999;
    publisher_->publish(pose_b_); // 发布隐藏B乌龟的消息
    // 随机更新B乌龟的位置
    std::uniform_real_distribution<> dist(-boundary_, boundary_);
    pose_b_.pose.position.x = dist(random_gen_);
    pose_b_.pose.position.y = dist(random_gen_);
    // 检查并规避边界
    if (check_boundary(pose_b_.pose.position)) {
      change_direction(pose_b_);
    }
    // 发布B乌龟的新位置
    pose_b_.header.stamp = node_->now();
    publisher_->publish(pose_b_);
    } else {
      // 简单的追逐逻辑：向B乌龟的方向移动
      twist.linear.x = 0.5;  // 向前的速度
      twist.angular.z = std::atan2(dy, dx);  // 根据目标方向计算角速度
      
      if (check_boundary(pose_a_.pose.position)) {
      change_direction(pose_a_);
    }

    // 发布A乌龟的新位置
    pose_a_.header.stamp = node_->now();
    publisher_->publish(pose_a_);
    }
  }

    std::shared_ptr<rclcpp::Node> get_node() {
    return node_;
  }

private:
  rclcpp::Node::SharedPtr node_;
  rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr subscriber_;
  rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr publisher_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_publisher_;
  std::mt19937 random_gen_;
  double boundary_;
  geometry_msgs::msg::PoseStamped pose_a_;
  geometry_msgs::msg::PoseStamped pose_b_;

  void update_turtle_b_position() {
    // 随机生成B乌龟的新位置
    std::uniform_real_distribution<> dist(-boundary_, boundary_);
    pose_b_.pose.position.x = dist(random_gen_);
    pose_b_.pose.position.y = dist(random_gen_);

    // 检查并规避边界
    if (check_boundary(pose_b_.pose.position)) {
      change_direction(pose_b_);
    }

    // 发布B乌龟的新位置
    pose_b_.header.stamp = node_->now();
    publisher_->publish(pose_b_);
  }

  bool check_boundary(const geometry_msgs::msg::Point& point) {
    return std::abs(point.x) > boundary_ || std::abs(point.y) > boundary_;
  }

  void change_direction(geometry_msgs::msg::PoseStamped& pose) {
    // 如果B乌龟碰到边界，就改变其方向
    if (pose.pose.position.x > boundary_) pose.pose.position.x = -boundary_;
    if (pose.pose.position.x < -boundary_) pose.pose.position.x = boundary_;
    if (pose.pose.position.y > boundary_) pose.pose.position.y = -boundary_;
    if (pose.pose.position.y < -boundary_) pose.pose.position.y = boundary_;
  }

  double calculate_distance(const geometry_msgs::msg::Point& p1, const geometry_msgs::msg::Point& p2) {
    return std::sqrt(std::pow(p2.x - p1.x, 2) + std::pow(p2.y - p1.y, 2));
  }
};

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  Chaser chaser;
  rclcpp::spin(chaser.get_node());
  rclcpp::shutdown();
  return 0;
}