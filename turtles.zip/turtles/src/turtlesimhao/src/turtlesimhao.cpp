#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/twist.hpp" 
#include <chrono>
#include <memory>
#include <random>
class TurtleSim {
  public:
    TurtleSim() {
      node_ = std::make_shared<rclcpp::Node>("turtlesim");
      publisher_ = node_->create_publisher<geometry_msgs::msg::PoseStamped>("turtles_pose", 10);
      cmd_vel_publisher_ = node_->create_publisher<geometry_msgs::msg::Twist>("turtle2/cmd_vel", 10);
  
      auto timer_callback = [this]() { update(); };
      timer_ = node_->create_wall_timer(
        std::chrono::milliseconds(500), timer_callback
      );
  
      randomize_positions();
      std::random_device rd;
      random_gen_ = std::mt19937(rd());
      boundary_ = 5.0; // 设置边界
    }
  
  void update() {
      // 检查并规避撞墙
      if (check_boundary(pose_a_.pose.position)) {
    change_direction(pose_a_);}
      if (check_boundary(pose_b_.pose.position)) {
    change_direction(pose_b_);}
  
      // 更新A乌龟的位置以追逐B乌龟
      double distance = calculate_distance(pose_a_.pose.position, pose_b_.pose.position);
      if (distance < 1.0) {
        // A乌龟追逐到B乌龟，隐藏轨迹并重置B乌龟的位置
        geometry_msgs::msg::PoseStamped empty_pose;
        empty_pose.header.stamp = node_->now();
        publisher_->publish(empty_pose); // 发布空消息以模拟隐藏轨迹
        randomize_positions();
      } else {
        pose_a_.pose.position.x += (pose_b_.pose.position.x - pose_a_.pose.position.x) * 0.1;
        pose_a_.pose.position.y += (pose_b_.pose.position.y - pose_a_.pose.position.y) * 0.1;
      }
  
      // 发布新位置
      pose_a_.header.stamp = node_->now();
      pose_b_.header.stamp = node_->now();
      publisher_->publish(pose_a_);
      publisher_->publish(pose_b_);

       geometry_msgs::msg::Twist twist;
      randomize_velocity(twist);
      cmd_vel_publisher_->publish(twist);
    }

   std::shared_ptr<rclcpp::Node> get_node() {
      return node_;
    }
  
  private:
    std::shared_ptr<rclcpp::Node> node_;
    rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_publisher_;
    geometry_msgs::msg::PoseStamped pose_a_, pose_b_;
    double boundary_;
    std::mt19937 random_gen_;
  
    void randomize_velocity(geometry_msgs::msg::Twist& twist) {
    // 随机化线速度和角速度
    std::uniform_real_distribution<> dist(-1.0, 1.0);
    twist.linear.x = dist(random_gen_);
    twist.angular.z = dist(random_gen_);
    }
    
    void randomize_positions() {
      std::random_device rd;
      std::mt19937 gen(rd());
      std::uniform_real_distribution<> dis(-boundary_, boundary_);
      pose_a_.pose.position.x = dis(gen);
      pose_a_.pose.position.y = dis(gen);
      pose_b_.pose.position.x = dis(gen);
      pose_b_.pose.position.y = dis(gen);
    }
  
    bool check_boundary(const geometry_msgs::msg::Point& point) {
      return std::abs(point.x) >= (boundary_ - 1.0) || std::abs(point.y) >= (boundary_ - 1.0);
    }
  
    void change_direction(geometry_msgs::msg::PoseStamped& pose) {
      if (pose.pose.position.x >= (boundary_ - 1.0)) {
        pose.pose.position.x = boundary_ - 2.0; // 稍微小于边界值
      } else if (pose.pose.position.x <= -(boundary_ - 1.0)) {
        pose.pose.position.x = -(boundary_ - 2.0);
      }
      if (pose.pose.position.y >= (boundary_ - 1.0)) {
        pose.pose.position.y = boundary_ - 2.0;
      } else if (pose.pose.position.y <= -(boundary_ - 1.0)) {
        pose.pose.position.y = -(boundary_ - 2.0);
      }
    }
  
    double calculate_distance(const geometry_msgs::msg::Point& p1, const geometry_msgs::msg::Point& p2) {
      return std::sqrt(std::pow(p2.x - p1.x, 2) + std::pow(p2.y - p1.y, 2));
    }
  };
  
  int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    auto turtlesim = std::make_shared<TurtleSim>();
    rclcpp::spin(turtlesim->get_node());
    rclcpp::shutdown();
    return 0;
  }
